
public class DoublePair {
	public Double num1;
	public Double num2;
	public DoublePair(Double inum1,Double inum2)
	{
		num1 = inum1;
		num2=inum2;
	}
}
