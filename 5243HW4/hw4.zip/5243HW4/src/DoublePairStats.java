
public class DoublePairStats {

	public int numOfObjects = 0;
	
	public double num1Average = 0;
	public double num2Average = 0;
	public double num1Std = 0;
	public double num2Std = 0;
	public double num1Min = 0;
	public double num1Max = 0;
	public double num2Min = 0;
	public double num2Max = 0;
}
